SOLAIRIA was written by Russ on 18 Jan 2024. Updated as of 28 Jan 2024.

1) For the default '.gguf' AI chat model that SOLAIRIA was tested with, go here:
https://huggingface.co/TheBloke/Llama-2-7b-Chat-GGUF/blob/main/llama-2-7b-chat.Q5_K_S.gguf

2) For other '.gguf' models, go to the site below, filter based on "gguf" or "gguf chat" keywords, download your desired model and place in this folder:
https://huggingface.co/models

NOTE 1: You should only have one '.gguf' model in the \model\ folder. If you have more than one, rename the extensions of unused models to '.ggufold' or anything you want so that the program does not detect them as '.gguf'.

NOTE 2: Only text-generation type of LLMs can be loaded.

NOTE 3: The 7B, 13B etc value in the model names is the number of parameters in the model. Generally, higher number = more parameters = better quality = more demanding on hardware (and may hang if hardware is not capable enough). Normal consumer-grade CPU/GPU can run 7B and 13B models comfortably. Read the accompanying Model Cards on HuggingFace for more info on each model.